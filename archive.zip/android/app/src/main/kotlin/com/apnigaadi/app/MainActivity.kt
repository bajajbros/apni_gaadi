package com.apnigaadi.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
